create
    definer = root@localhost procedure boxerRanking()
BEGIN
    select 
        user.id AS user_id, user.username AS boxer, COUNT(subscription.id) AS numberMatch, SUM(subscription.points) AS totalPoints
    from user
    left join subscription ON user.id = subscription.user_id
    where user.role = 'boxer'
    group by user.id, user.username;


END;

