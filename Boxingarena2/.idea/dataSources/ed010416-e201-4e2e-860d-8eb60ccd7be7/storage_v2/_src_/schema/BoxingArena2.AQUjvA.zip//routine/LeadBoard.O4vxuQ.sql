create
    definer = root@localhost procedure LeadBoard()
BEGIN
	select 
		user.id AS user_id, user.username AS driver, COUNT(subscription.id) AS numberRace, SUM(subscription.points) AS totalPoints
	from user
    left join subscription ON user.id = subscription.user_id
    where user.role = 'driver'
    group by user.id, user.username;


END;

