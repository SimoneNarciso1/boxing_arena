create
    definer = root@localhost procedure prova()
BEGIN
	insert into user (username, password, role) values ('ale', '123', 'Admin');
END;

